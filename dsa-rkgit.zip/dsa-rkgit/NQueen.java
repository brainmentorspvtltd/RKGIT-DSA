public class NQueen {
    boolean board[][] = new boolean[4][4]; // fill with all false
    static int countNQueen(int row){
        return 0;
    }
    public static void main(String[] args) {
        System.out.println(countNQueen(0));
    }
}
