import java.util.ArrayList;

class Board{
    static ArrayList<String> showBoardPos(int startRow, int startCol, int endRow, int endCol){
        if(startRow==endRow && startCol==endCol){
            ArrayList<String> list = new ArrayList<>();
            list.add("");
            return list;

        }
        if(startRow>endRow || startCol>endCol){
            ArrayList<String> list = new ArrayList<>(); // Empty List
            return list;
        }
        ArrayList<String> finalList = new ArrayList<>();
        //Move to the Right
        ArrayList<String> tempList = showBoardPos(startRow, startCol+1, endRow, endCol);
        for(String t : tempList){
            finalList.add(t+"R");
        }
        // Move to the Down
         tempList = showBoardPos(startRow+1, startCol, endRow, endCol);
         for(String t : tempList){
            finalList.add(t+"D");
        }
        return finalList;
    }
    public static void main(String[] args) {
        ArrayList<String> r = showBoardPos(0, 0, 2, 2);
        System.out.println(r);
    }
}